#! /bin/sh
java -jar Topic-Distribution-0.0.1-SNAPSHOT.jar
